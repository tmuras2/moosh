<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = 'KE8OPdWWfaT865CeURIZekjKS9hG0A1Blocalhost';
$CFG->bootstraphash = '174f8ecbacce6c6ef3340b30ecc1eab5';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
