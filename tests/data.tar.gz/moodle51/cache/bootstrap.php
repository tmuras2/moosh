<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = 'D0RsoRbYTdv9rZaSuMrYBNRX1meUMu1hlocalhost';
$CFG->bootstraphash = '174f8ecbacce6c6ef3340b30ecc1eab5';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
